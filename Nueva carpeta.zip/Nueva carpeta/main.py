from capaDatos.dPersona import DPersona

objetoPrueba = DPersona()
print(objetoPrueba.mostrarPersona())
